#Neighborhood Map

####This project is make with knockout JS and google maps API

### Expected Functionality
All application components render on-screen in a responsive manner.

Google map loaded from Maps API.

Map markers located at Points of Interest 

Points of interest data loaded via Foursquare API

API errors are handled with warning message at top of page
Points of Interest markers all present upon page load


##Attributions
Google Maps API

Four Square API

##Resourses 
 https://developers.google.com/maps/documentation/javascript/adding-a-google-map

https://github.com/matosb2/P5/blob/develop/src/js/main.js

https://stackoverflow.com/questions/45422066/set-marker-visible-with-knockout-js-ko-utils-arrayfilter
